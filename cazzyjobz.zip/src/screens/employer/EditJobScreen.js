import React, { useState, useEffect } from 'react';
import {
  View,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  Modal
} from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import { Button } from '../../components/common/Button';
import { COLORS, SIZES } from '../../styles/theme';
import JobCategoryField from '../jobs/post/components/JobCategoryField';
import JobLocationField from '../jobs/post/components/JobLocationField';
import JobDateTimeField from '../jobs/post/components/JobDateTimeField';
import JobBudgetField from '../jobs/post/components/JobBudgetField';
import { supabase } from '../../utils/supabaseClient';
import { storageService } from '../../utils/storageService';

export default function EditJobScreen() {
  const route = useRoute();
  const navigation = useNavigation();
  const { jobId } = route.params;
  
  const [formData, setFormData] = useState({
    category: '',
    description: '',
    location_city: '',
    location_suburb: '',
    scheduled_date: '',
    start_time: '',
    end_time: '',
    duration_hours: '',
    budget: '',
  });

  const [showConfirmation, setShowConfirmation] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);

  // Load job data for editing
  useEffect(() => {
    const loadJobData = async () => {
      try {
        // Try local storage first
        const localJobs = await storageService.getMyJobs();
        const jobToEdit = localJobs.find(job => job.id === jobId);
        
        if (jobToEdit) {
          populateForm(jobToEdit);
          setLoading(false);
        }

        // Then verify with Supabase
        const { data, error } = await supabase
          .from('jobs')
          .select('*')
          .eq('id', jobId)
          .single();

        if (error) throw error;

        if (data) {
          populateForm(data);
        }

      } catch (error) {
        console.error('❌ Error loading job for editing:', error);
        Alert.alert('Error', 'Failed to load job details for editing');
      } finally {
        setLoading(false);
      }
    };

    loadJobData();
  }, [jobId]);

  const populateForm = (job) => {
    setFormData({
      category: job.category || '',
      description: job.description || '',
      location_city: job.location_city || '',
      location_suburb: job.location_suburb || '',
      scheduled_date: job.scheduled_date || '',
      start_time: job.time_from || '',
      end_time: job.time_to || '',
      duration_hours: job.duration_hours?.toString() || '',
      budget: job.budget?.toString() || '',
    });
  };

  // Basic field update function
  const updateField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Time field update with auto-calculation
  const updateTimeField = (field, value) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      
      // Auto-calculate hours if both times are set
      if (newData.start_time && newData.end_time) {
        const start = new Date(`2000-01-01 ${newData.start_time}`);
        const end = new Date(`2000-01-01 ${newData.end_time}`);
        const diffMs = end - start;
        const hours = (diffMs / (1000 * 60 * 60)).toFixed(1);
        newData.duration_hours = hours > 0 ? hours : '';
      }
      
      return newData;
    });
  };

  // Simple validation
  const validateForm = () => {
    if (!formData.category) {
      Alert.alert('Missing Category', 'Please select a job category');
      return false;
    }
    if (!formData.description) {
      Alert.alert('Missing Description', 'Please describe the work needed');
      return false;
    }
    if (!formData.location_city || !formData.location_suburb) {
      Alert.alert('Missing Location', 'Please enter city and suburb');
      return false;
    }
    if (!formData.scheduled_date) {
      Alert.alert('Missing Date', 'Please select a date');
      return false;
    }
    if (!formData.start_time || !formData.end_time) {
      Alert.alert('Missing Time', 'Please select start and end times');
      return false;
    }
    if (!formData.budget) {
      Alert.alert('Missing Budget', 'Please enter a budget');
      return false;
    }
    return true;
  };

  const handlePreview = () => {
    if (validateForm()) {
      setShowConfirmation(true);
    }
  };

  const handleUpdateJob = async () => {
    if (isSubmitting) return;
    
    setIsSubmitting(true);
    
    try {
      const jobData = {
        category: formData.category,
        description: formData.description,
        location_city: formData.location_city,
        location_suburb: formData.location_suburb,
        address_text: `${formData.location_suburb}, ${formData.location_city}`,
        scheduled_date: formData.scheduled_date,
        time_from: formData.start_time,
        time_to: formData.end_time,
        duration_hours: parseFloat(formData.duration_hours) || 0,
        budget: parseFloat(formData.budget) || 0,
        budget_currency: 'ZAR',
        updated_at: new Date().toISOString(),
      };

      console.log('📤 TYPE A CALL - Updating job in Supabase:', jobData);

      // Update in Supabase
      const { data, error } = await supabase
        .from('jobs')
        .update(jobData)
        .eq('id', jobId)
        .select()
        .single();

      if (error) throw error;

      console.log('✅ Job updated successfully in Supabase:', data.id);

      // Update local storage
      const localJobs = await storageService.getMyJobs();
      const updatedJobs = localJobs.map(job => 
        job.id === jobId ? { ...job, ...jobData } : job
      );
      await storageService.setMyJobs(updatedJobs);
      console.log('💾 Job updated in local storage');

      // Success
      setShowConfirmation(false);
      Alert.alert('Success', 'Job updated successfully!');
      navigation.goBack(); // Go back to JobDetailScreen
      
    } catch (error) {
      console.error('💥 Job update error:', error);
      Alert.alert(
        'Update Failed', 
        error.message || 'Could not update your job. Please check your connection and try again.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <Text style={styles.loadingText}>Loading job for editing...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: COLORS.white }}>
      <View style={{ padding: SIZES.padding, paddingBottom: 80 }}>
        {/* Header */}
        <Text style={styles.screenTitle}>Edit Job</Text>
        <Text style={styles.requiredNote}>
          Update the job details below
        </Text>

        {/* Reuse all the field components from PostJobScreen */}
        <JobCategoryField
          value={formData.category}
          onChange={(value) => updateField('category', value)}
        />

        {/* Description */}
        <View style={{ marginBottom: SIZES.margin }}>
          <Text style={styles.fieldLabel}>Job Description</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={formData.description}
            onChangeText={(value) => updateField('description', value)}
            placeholder="Describe the work needed, requirements, tools, etc."
            placeholderTextColor={COLORS.gray500}
            multiline
            numberOfLines={3}
            maxLength={500}
          />
          <Text style={styles.charCount}>
            {formData.description.length}/500
          </Text>
        </View>

        <JobLocationField
          city={formData.location_city}
          suburb={formData.location_suburb}
          onChange={updateField}
          showSuccessPopup={false}
        />

        <JobDateTimeField
          date={formData.scheduled_date}
          startTime={formData.start_time}
          endTime={formData.end_time}
          hours={formData.duration_hours}
          onChange={updateField}
          onTimeChange={updateTimeField}
        />

        <JobBudgetField
          value={formData.budget}
          onChange={(value) => updateField('budget', value)}
        />

        {/* Update Button */}
        <Button
          title="Preview & Update Job"
          onPress={handlePreview}
          style={{ marginTop: SIZES.margin }}
          loading={isSubmitting}
        />

        {/* Confirmation Modal */}
        <Modal visible={showConfirmation} transparent animationType="slide">
          <View style={styles.modalOverlay}>
            <View style={styles.modalCard}>
              <Text style={styles.modalTitle}>Confirm Job Updates</Text>
              
              <View style={styles.previewSection}>
                <Text style={styles.previewText}>
                  <Text style={styles.previewLabel}>Category: </Text>
                  {formData.category}
                </Text>
                <Text style={styles.previewText}>
                  <Text style={styles.previewLabel}>Location: </Text>
                  {formData.location_suburb}, {formData.location_city}
                </Text>
                <Text style={styles.previewText}>
                  <Text style={styles.previewLabel}>Date: </Text>
                  {formData.scheduled_date}
                </Text>
                <Text style={styles.previewText}>
                  <Text style={styles.previewLabel}>Time: </Text>
                  {formData.start_time} - {formData.end_time}
                </Text>
                <Text style={styles.previewText}>
                  <Text style={styles.previewLabel}>Duration: </Text>
                  {formData.duration_hours ? `${formData.duration_hours} hours` : '-- hours'}
                </Text>
                <Text style={styles.previewText}>
                  <Text style={styles.previewLabel}>Budget: </Text>
                  R {formData.budget}
                </Text>
              </View>

              <View style={styles.buttonRow}>
                <Button
                  title="Cancel"
                  onPress={() => setShowConfirmation(false)}
                  style={[styles.button, { backgroundColor: COLORS.gray500 }]}
                />
                <Button
                  title={isSubmitting ? "Updating..." : "Update Job"}
                  onPress={handleUpdateJob}
                  style={styles.button}
                  loading={isSubmitting}
                />
              </View>
            </View>
          </View>
        </Modal>
      </View>
    </ScrollView>
  );
}

const styles = {
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  screenTitle: {
    fontSize: SIZES.xLarge,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 8,
    textAlign: 'center',
    marginTop: 12,
  },
  requiredNote: {
    color: COLORS.gray500,
    fontSize: SIZES.xSmall,
    textAlign: 'center',
    marginBottom: SIZES.margin,
    fontStyle: 'italic',
  },
  fieldLabel: {
    fontSize: SIZES.small,
    fontWeight: '600',
    color: COLORS.gray700,
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: COLORS.gray300,
    borderRadius: SIZES.radius,
    padding: 12,
    fontSize: SIZES.small,
    backgroundColor: COLORS.white,
    color: COLORS.gray800,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  charCount: {
    color: COLORS.gray500,
    fontSize: SIZES.xSmall,
    marginTop: 4,
    textAlign: 'right',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: SIZES.padding,
  },
  modalCard: {
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radius * 2,
    padding: SIZES.padding * 1.2,
    width: '100%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: SIZES.large,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: SIZES.margin,
    textAlign: 'center',
  },
  previewSection: {
    backgroundColor: COLORS.gray100,
    padding: SIZES.padding,
    borderRadius: SIZES.radius,
    marginBottom: SIZES.margin,
  },
  previewText: {
    fontSize: SIZES.small,
    marginBottom: 6,
  },
  previewLabel: {
    fontWeight: '600',
    color: COLORS.gray700,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    flex: 0.48,
  },
  loadingText: {
    textAlign: 'center',
    color: COLORS.gray500,
    fontSize: SIZES.medium,
  },
};